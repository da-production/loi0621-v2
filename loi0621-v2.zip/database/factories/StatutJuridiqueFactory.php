<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\statutJuridique;
use Faker\Generator as Faker;

$factory->define(statutJuridique::class, function (Faker $faker) {
    return [
        //
    ];
});
