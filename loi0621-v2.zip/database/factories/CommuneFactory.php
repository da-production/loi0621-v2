<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Commune;
use Faker\Generator as Faker;

$factory->define(Commune::class, function (Faker $faker) {
    return [
        //
    ];
});
