<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\UserDisabled;
use Faker\Generator as Faker;

$factory->define(UserDisabled::class, function (Faker $faker) {
    return [
        //
    ];
});
