<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\CodePosteau;
use Faker\Generator as Faker;

$factory->define(CodePosteau::class, function (Faker $faker) {
    return [
        //
    ];
});
