<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\HasMessage;
use Faker\Generator as Faker;

$factory->define(HasMessage::class, function (Faker $faker) {
    return [
        //
    ];
});
