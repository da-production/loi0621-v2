<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Administrateur;
use Faker\Generator as Faker;

$factory->define(Administrateur::class, function (Faker $faker) {
    return [
        //
    ];
});
