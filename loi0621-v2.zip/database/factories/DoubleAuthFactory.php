<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\DoubleAuth;
use Faker\Generator as Faker;

$factory->define(DoubleAuth::class, function (Faker $faker) {
    return [
        //
    ];
});
