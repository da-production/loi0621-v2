<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Branche;
use Faker\Generator as Faker;

$factory->define(Branche::class, function (Faker $faker) {
    return [
        //
    ];
});
