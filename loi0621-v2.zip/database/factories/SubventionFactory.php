<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Subvention;
use Faker\Generator as Faker;

$factory->define(Subvention::class, function (Faker $faker) {
    return [
        //
    ];
});
