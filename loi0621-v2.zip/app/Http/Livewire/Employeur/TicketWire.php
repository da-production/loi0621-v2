<?php

namespace App\Http\Livewire\Employeur;

use Livewire\Component;

class TicketWire extends Component
{
    public function render()
    {
        return view('livewire.employeur.ticket-wire');
    }
}
