<?php

namespace App\Http\Livewire\Administrateur;

use Livewire\Component;

class TicketMessageWire extends Component
{
    public function render()
    {
        return view('livewire.administrateur.ticket-message-wire');
    }
}
