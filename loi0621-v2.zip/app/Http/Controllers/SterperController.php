<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SterperController extends Controller
{
    //
}
