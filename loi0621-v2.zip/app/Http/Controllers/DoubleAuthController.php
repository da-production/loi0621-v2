<?php

namespace App\Http\Controllers;

use App\Models\DoubleAuth;
use Illuminate\Http\Request;

class DoubleAuthController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\DoubleAuth  $doubleAuth
     * @return \Illuminate\Http\Response
     */
    public function show(DoubleAuth $doubleAuth)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DoubleAuth  $doubleAuth
     * @return \Illuminate\Http\Response
     */
    public function edit(DoubleAuth $doubleAuth)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\DoubleAuth  $doubleAuth
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DoubleAuth $doubleAuth)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\DoubleAuth  $doubleAuth
     * @return \Illuminate\Http\Response
     */
    public function destroy(DoubleAuth $doubleAuth)
    {
        //
    }
}
