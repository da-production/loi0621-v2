<?php

namespace App\Http\Controllers;

use App\Models\UserDisabled;
use Illuminate\Http\Request;

class UserDisabledController extends Controller
{
    
}
