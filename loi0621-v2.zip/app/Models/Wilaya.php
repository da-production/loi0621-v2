<?php

namespace App\Models;

use App\Traits\SsmsDateTime;
use Illuminate\Database\Eloquent\Model;

class Wilaya extends Model
{
    //
    use SsmsDateTime;
}
