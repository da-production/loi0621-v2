@extends('layouts.employeur')

@section('content')
    {!! $message->content_fr !!}
@endsection