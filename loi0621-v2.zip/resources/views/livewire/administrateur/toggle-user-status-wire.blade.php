<button class="btn btn-sm btn-{{ $status ? 'warning' : 'success' }} text-sm" wire:click="toggle">{{ $text }}</button>
