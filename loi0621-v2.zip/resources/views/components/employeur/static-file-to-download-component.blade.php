<div class="element-wrapper" data-step="4" data-intro="Rubrique de Téléchargement et d'Insertion, 
    ici vous trouverez les fichiers à télécharger ainsi que ceux à insérer" >
    <h6 class="element-header">
        à Télécharger
    </h6>
    <div class="element-box-tp">
        <div class="el-buttons-list full-width">
            <a class="btn btn-light btn-sm" href="{{ route('subvention.download.files',['name'=>'DemandeOctroiSubventionMensuelleEmploiDv']) }}"><i class="os-icon os-icon-download-cloud"></i> <span>Demande Octroi Subvention Mensuelle Emploi</span></a>
            <a class="btn btn-light btn-sm" href="{{ route('subvention.download.files',['name'=>'EtatRecrutementParCDIDv']) }}"><i class="os-icon os-icon-download-cloud"></i> <span>Etat Recrutement Par CDI</span></a>
        </div>
    </div>
</div>