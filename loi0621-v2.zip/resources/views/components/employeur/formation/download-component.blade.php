<div class="element-wrapper" data-step="4" data-intro="Rubrique de Téléchargement et d'Insertion, 
    ici vous trouverez les fichiers à télécharger ainsi que ceux à insérer" >
    <h6 class="element-header">
        à Télécharger
    </h6>
    <div class="element-box-tp">
        <div class="el-buttons-list full-width">
            <a class="btn btn-primary btn-sm" href="{{ route('formation.download.files',['name'=>'EtatTravailleursAyantBeneficieFormationDv']) }}">
                <i class="os-icon os-icon-download-cloud"></i> <span>Etat Travailleurs Ayant Beneficie Formation Dv</span>
            </a>
            <a class="btn btn-primary btn-sm" href="{{ route('formation.download.files',['name'=>'DemandeRemboursementCotisationGlobaleSSDv']) }}">
                <i class="os-icon os-icon-download-cloud"></i> <span>Demande Remboursement Cotisation Globale SSDv</span>
            </a>
        </div>
    </div>
</div>